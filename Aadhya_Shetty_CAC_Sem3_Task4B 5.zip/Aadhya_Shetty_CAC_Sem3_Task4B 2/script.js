function showDescription() {
  const description = document.getElementById('description');
  
  // Toggle the visibility of the description
  if (description.style.display === 'none') {
    description.style.display = 'block'; // Show the description
  } else {
    description.style.display = 'none'; // Hide the description
  }
}

// Create the scroll-down container
const scrollDownContainer = document.createElement('div');
scrollDownContainer.style.position = 'fixed';
scrollDownContainer.style.bottom = '10px';
scrollDownContainer.style.left = '50%';
scrollDownContainer.style.transform = 'translateX(-50%)';
scrollDownContainer.style.textAlign = 'center';
scrollDownContainer.style.color = '#fff';
scrollDownContainer.style.fontSize = '16px';
scrollDownContainer.style.fontWeight = 'bold';
scrollDownContainer.style.cursor = 'pointer';
scrollDownContainer.style.zIndex = '1000'; // Ensures it’s on top of other elements

// Add text to the container
const scrollText = document.createElement('p');
scrollText.textContent = 'Scroll for more info';
scrollText.style.margin = '0';
scrollDownContainer.appendChild(scrollText);

// Add the arrow with animation
const arrow = document.createElement('span');
arrow.innerHTML = '&#x25BC;'; // Down arrow symbol
arrow.style.display = 'block';
arrow.style.fontSize = '24px';
arrow.style.marginTop = '-10px';
arrow.style.animation = 'bounce 1s infinite';

// Add keyframes for bounce animation
const styleSheet = document.createElement('style');
styleSheet.type = 'text/css';
styleSheet.innerText = `
  @keyframes bounce {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(10px); }
  }
`;
document.head.appendChild(styleSheet);

scrollDownContainer.appendChild(arrow);
document.body.appendChild(scrollDownContainer);

// Add smooth scrolling effect on click
scrollDownContainer.addEventListener('click', function() {
  window.scrollBy({
    top: window.innerHeight,
    behavior: 'smooth'
  });
});

let userScore = 0;
let deepfakeScore = 0;
let musicPlaying = false;
const music = document.getElementById("background-music");

// Start the game
function startGame() {
  // Hide the home screen and show level 1
  document.getElementById("home-screen").style.display = "none";
  document.getElementById("level1").style.display = "flex";
  updateScoreDisplay(); // Update the score display at the start
}

// Update the score display
function updateScoreDisplay() {
  document.getElementById("score-display").textContent = `You: ${userScore} | Deepfake: ${deepfakeScore}`;
}

const correctAnswers = {
  level1: { 1: 'A', 2: 'B', 3: 'A' } // Correct answers for each round in level 1
};

function selectAnswer(levelId, round, answer) {
  const feedback = document.getElementById(`${levelId}-feedback`);

  // Check if the selected answer is correct
  if (answer === correctAnswers[levelId][round]) {
    feedback.textContent = `Correct! You chose the right answer for Round ${round}.`;
    feedback.style.color = 'green';
    userScore++; // Increment user score
  } else {
    feedback.textContent = `Incorrect. The correct answer for Round ${round} was ${correctAnswers[levelId][round]}.`;
    feedback.style.color = 'red';
    deepfakeScore++; // Increment deepfake score
  }
  updateScoreDisplay(); // Update the score display



  // Show feedback
  feedback.style.display = 'block';

  // Hide the current round and show the next round after a short delay
  setTimeout(() => {
    document.getElementById(`${levelId}-round${round}`).style.display = 'none';

    if (round < 3) {
      document.getElementById(`${levelId}-round${round + 1}`).style.display = 'block';
    } else {
      feedback.textContent = "Level 1 complete! Moving to Level 2...";
      feedback.style.color = 'white';

      setTimeout(() => {
        feedback.style.display = 'none';
        document.getElementById(levelId).style.display = 'none';
        document.getElementById('level2').style.display = 'block';
      }, 2000);
    }
  }, 2000);
}


// Handle the answers for Level 2
function answerLevel2(choice) {
  const feedback = document.getElementById("level2-feedback");
  feedback.style.display = "block";
  
  if (choice === 'A') {
    feedback.textContent = "Correct!";
    feedback.style.color = "green";
    userScore++; // Increment user score
  } else {
    feedback.textContent = "Incorrect!";
    feedback.style.color = "red";
    deepfakeScore++; // Increment deepfake score
  }
  
  updateScoreDisplay(); // Update the score display
  

  // Move to the next level after a delay
  setTimeout(() => {
    document.getElementById("level2").style.display = "none"; // Hide Level 2
    document.getElementById("level3").style.display = "flex"; // Show Level 3
  }, 2000); // Delay for feedback
}

// Show Crime or Law category in Level 3
function showCategory(category) {
  document.getElementById("crime-section").style.display = (category === 'crime') ? "block" : "none";
  document.getElementById("law-section").style.display = (category === 'law') ? "block" : "none";
}


// Toggle the music on/off
function toggleMusic() {
  if (musicPlaying) {
    music.pause(); // Pause the music
  } else {
    music.play(); // Play the music
  }
  musicPlaying = !musicPlaying; // Toggle the music playing state
}

// Toggle fullscreen mode
function toggleFullScreen() {
  if (!document.fullscreenElement) {
    document.documentElement.requestFullscreen(); // Enter fullscreen
  } else if (document.exitFullscreen) {
    document.exitFullscreen(); // Exit fullscreen
  }
}// Function to toggle the popup (open/close)
function openPopup() {
  const popup = document.getElementById("popup");
  
  // Check if the popup is currently displayed
  if (popup.style.display === "flex") {
    popup.style.display = "none"; // Hide the popup if it's open
  } else {
    popup.style.display = "flex"; // Show the popup if it's closed
  }
}

// Function to close the popup manually (when the close button is clicked)
function closePopup() {
  document.getElementById("popup").style.display = "none";
}


// Finish the game and reload the page
function finishGame() {
  alert(`Congratulations! Final Score - You: ${userScore}, Deepfake: ${deepfakeScore}`);
  location.reload(); // Reload the page to restart the game
}
